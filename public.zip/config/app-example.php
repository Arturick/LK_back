<?php

return [
    'displayErrorDetails' => true,
    'secret' => 'c4e250aed1813a0b4bbe5a01532649',
    'root_dir' => 'D:\OSPanel\domains\wbtools\server',
    'domain' => '/wbtools',
    'dadata_api_key' => '57eb82c6a4b76b07c18a8822dcc60d126073a2c9',
    'jwt_salt' => '779560',
];