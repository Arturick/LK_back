<?php

return [
    // prod
    // 'rate' => [
    //     'driver' => 'mysql',
    //     'host' => 'j45316134.myjino.ru',
    //     'port' => '3306',
    //     'db' => 'j45316134',
    //     'user' => 'j45316134',
    //     'password' => 'cf}j}R75tRzM'
    // ]

    // dev
    'rate' => [
        'driver' => 'mysql',
        'host' => 'r92237up.beget.tech',
        'port' => '3306',
        'db' => 'r92237up_rate',
        'user' => 'r92237up_rate',
        'password' => '2w6tSvH&'
    ]
];
